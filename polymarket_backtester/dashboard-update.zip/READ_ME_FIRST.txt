UPDATE YOUR EXISTING DASHBOARD

1. Close the black RunDashboard launcher window.
2. Extract this small ZIP.
3. Copy app.py from this ZIP into the polymarket_backtester folder you already use.
   Choose Replace when Windows asks. This is the same folder as RunDashboard.bat.
4. Double-click RunDashboard.bat again and refresh the browser page.

Start here explains the strategy research workflow.
Charts lets you select a date and 15-minute interval, then use Previous/Next.
Check Show Up/Down contract history for the actual recorded contract observations
and prices at minutes 10-13, including observation age.

Historical charts often contain 15-second samples, not every second. Missing data
is not filled. No data, strategies or frozen validation results are changed by this update.
