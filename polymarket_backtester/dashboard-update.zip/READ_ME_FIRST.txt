UPDATE THE DASHBOARD ONLY

1. Close the black RunDashboard launcher window.
2. Extract this ZIP and copy app.py into your existing polymarket_backtester folder.
   This is the folder containing RunDashboard.bat. Choose Replace.
3. Double-click RunDashboard.bat again and refresh the browser page.

Development strategies now opens Strategy Lab:
- Choose entry minute (10, 11, 12 or 13).
- Enter a minimum Bitcoin dollar gap above/below the opening target.
- Set the bid amount with the slider.
- Optionally require the first-10-minute trend to agree.
- Click Test strategy for development-only wins/losses, win rate, modeled returns
  and a daily scenario estimate. Export daily results and compare tested rules.

Gap is distance from target, not slope or bid/ask spread. The rule chooses Up
above the target and Down below; it skips inside the gap. Daily income figures
are based on historical modeled results, not a forecast or guarantee.

The original data, engine and frozen validation results stay unchanged. Your
comparison list is session-only unless exported. Download all-data-csv.zip
separately for all collected CSV tables, including the finer historical samples.
