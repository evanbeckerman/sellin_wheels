ALL COLLECTED CSV TABLES
Window: September 19 through October 18, 2026 inclusive, UTC-08:00.
The original tables are unchanged. Missing observations remain blank.
The extra bitcoin_reference_samples.csv exports 145,939 actual finer-resolution
samples from the retained official historical chart responses. It does not
interpolate or manufacture second-by-second prices. Original raw source hashes
are included for provenance.

markets.csv: every requested interval and actual market metadata/outcomes.
reference_minutes.csv: recorded minute observations and reported boundaries.
bitcoin_reference_samples.csv: the finer original historical Bitcoin samples.
contract_history.csv: actual Up/Down observations, not executable asks.
contract_targets.csv: exact or prior observations at entry minutes, with age.
trades.csv: alternative actual trade prints, when collected; may be header-only.
issues.csv: actual collection and validation gaps.
features.csv: causal historical features used by the original research engine.
training_strategies.csv: original 192-rule development comparison; modeled returns.

A high historical win rate or modeled return is not a guaranteed future result.
The new interactive Strategy Lab's session tests are exported from its own
Download buttons. They do not change these frozen original research tables.
